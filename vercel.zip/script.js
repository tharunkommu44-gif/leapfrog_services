/**
 * LeapFrog — script.js
 * Vanilla JS, no frameworks or libraries
 * Covers: nav toggle, scroll fade-in, bar/timeline animation, method accordion
 */

(function () {
  'use strict';

  /* ── Utility: query helpers ── */
  const $  = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

  /* =============================================
     1. SET FOOTER YEAR
     ============================================= */
  const yearEl = $('#footer-year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* =============================================
     2. MOBILE NAV TOGGLE
     ============================================= */
  const navToggle = $('.nav__toggle');
  const navMenu   = $('#nav-menu');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', function () {
      const isOpen = this.getAttribute('aria-expanded') === 'true';
      this.setAttribute('aria-expanded', String(!isOpen));
      navMenu.classList.toggle('nav__menu--open', !isOpen);
    });

    /* Close menu when a nav link is clicked */
    $$('.nav__link', navMenu).forEach(function (link) {
      link.addEventListener('click', function () {
        navToggle.setAttribute('aria-expanded', 'false');
        navMenu.classList.remove('nav__menu--open');
      });
    });

    /* Close menu on outside click */
    document.addEventListener('click', function (e) {
      if (!navToggle.contains(e.target) && !navMenu.contains(e.target)) {
        navToggle.setAttribute('aria-expanded', 'false');
        navMenu.classList.remove('nav__menu--open');
      }
    });

    /* Close on Escape */
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        navToggle.setAttribute('aria-expanded', 'false');
        navMenu.classList.remove('nav__menu--open');
        navToggle.focus();
      }
    });
  }

  /* =============================================
     3. SCROLL FADE-IN (IntersectionObserver)
     ============================================= */
  const fadeEls = $$('.fade-in');

  if ('IntersectionObserver' in window && fadeEls.length) {
    const fadeObserver = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            fadeObserver.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    );

    fadeEls.forEach(function (el) {
      fadeObserver.observe(el);
    });
  } else {
    /* Fallback: show everything if observer not supported */
    fadeEls.forEach(function (el) {
      el.classList.add('is-visible');
    });
  }

  /* =============================================
     4. ANIMATED BAR CHARTS (Velocity + Timeline)
        Fills when element enters viewport
     ============================================= */
  function animateBars(containerSelector, fillSelector) {
    const containers = $$(containerSelector);

    if (!('IntersectionObserver' in window) || !containers.length) {
      /* Fallback: set widths immediately */
      containers.forEach(function (container) {
        $$(fillSelector, container).forEach(function (fill) {
          fill.style.width = (fill.dataset.width || 0) + '%';
        });
      });
      return;
    }

    const barObserver = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            $$(fillSelector, entry.target).forEach(function (fill, i) {
              /* Stagger each bar slightly */
              setTimeout(function () {
                fill.style.width = (fill.dataset.width || 0) + '%';
              }, i * 80);
            });
            barObserver.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.3 }
    );

    containers.forEach(function (container) {
      barObserver.observe(container);
    });
  }

  animateBars('.velocity-card', '.bar-chart__fill');
  animateBars('.timeline-card', '.timeline-row__fill');

  /* =============================================
     5. METHOD STEPS ACCORDION
     ============================================= */
  const methodSteps = $$('.method__step');

  if (methodSteps.length) {
    methodSteps.forEach(function (step) {
      const btn  = $('.method__step-btn', step);
      const body = $('.method__step-body', step);

      if (!btn || !body) return;

      btn.addEventListener('click', function () {
        const isActive = step.classList.contains('method__step--active');

        /* Deactivate all steps */
        methodSteps.forEach(function (s) {
          s.classList.remove('method__step--active');
          const b = $('.method__step-btn', s);
          const p = $('.method__step-body', s);
          if (b) b.setAttribute('aria-expanded', 'false');
          if (p) p.hidden = true;
        });

        /* Activate clicked step (toggle off if already active) */
        if (!isActive) {
          step.classList.add('method__step--active');
          btn.setAttribute('aria-expanded', 'true');
          body.hidden = false;
        }
      });
    });
  }

  /* =============================================
     6. SMOOTH SCROLL for anchor links
        (CSS handles most of it; this ensures
         the fixed header offset is respected)
     ============================================= */
  const HEADER_HEIGHT = 64; /* px, matches CSS header height */

  $$('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      const target = $(this.getAttribute('href'));
      if (!target) return;

      e.preventDefault();

      const top = target.getBoundingClientRect().top + window.scrollY - HEADER_HEIGHT;

      window.scrollTo({ top: top, behavior: 'smooth' });

      /* Move focus for accessibility */
      target.setAttribute('tabindex', '-1');
      target.focus({ preventScroll: true });
    });
  });

  /* =============================================
     7. ACTIVE NAV LINK on scroll (highlight)
     ============================================= */
  const sections = $$('section[id], main section[id]');
  const navLinks = $$('.nav__link');

  if ('IntersectionObserver' in window && sections.length && navLinks.length) {
    const sectionObserver = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            const id = entry.target.getAttribute('id');
            navLinks.forEach(function (link) {
              const href = link.getAttribute('href');
              link.classList.toggle('nav__link--active', href === '#' + id);
            });
          }
        });
      },
      { rootMargin: '-40% 0px -55% 0px' }
    );

    sections.forEach(function (section) {
      sectionObserver.observe(section);
    });
  }

})();
